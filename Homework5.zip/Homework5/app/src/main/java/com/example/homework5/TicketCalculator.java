package com.example.homework5;

public class TicketCalculator {
    private AgeCategory age;
    private double taxRate;

    public TicketCalculator(){
    }

    public void setAge(AgeCategory ac){
        age = ac;
    }

    public void setTaxRate(double tr){
        taxRate = tr/100;
    }

    public double getBase(){
        return age.givePrice();
    }

    public double getTaxRate(){
        return age.givePrice()*taxRate;
    }

    public double getPrice(){
        return age.givePrice()*(1+taxRate);
    }
}

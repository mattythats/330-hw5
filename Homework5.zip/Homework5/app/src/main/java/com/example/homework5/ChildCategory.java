package com.example.homework5;

public class ChildCategory implements AgeCategory {
    private double price = 10;
    @Override
    public double givePrice() {
        return price;
    }
}

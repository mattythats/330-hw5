package com.example.homework5;

public interface AgeCategory {
    double givePrice();
}

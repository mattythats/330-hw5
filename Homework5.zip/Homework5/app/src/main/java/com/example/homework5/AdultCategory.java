package com.example.homework5;

public class AdultCategory implements AgeCategory {
    private double price = 15;
    @Override
    public double givePrice() {
        return price;
    }
}

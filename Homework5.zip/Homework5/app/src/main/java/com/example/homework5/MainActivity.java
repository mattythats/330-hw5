package com.example.homework5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private AgeCategory kid;
    private AgeCategory adult;
    private AgeCategory senior;
    private TextView base;
    private TextView tax;
    private TextView total;
    private EditText taxRate;
    private TicketCalculator ticket;
    private RadioGroup ageGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        kid = new ChildCategory();
        adult = new AdultCategory();
        senior = new SeniorCategory();
        base = (TextView) findViewById(R.id.subtotal_text);
        tax = (TextView) findViewById(R.id.tax_text);
        total = (TextView) findViewById(R.id.total_text);
        taxRate = (EditText) findViewById(R.id.tax_rate);
        ticket = new TicketCalculator();
        ageGroup = (RadioGroup) findViewById(R.id.age_group);
    }

    public void calcPrice(View v){
        int checkedId = ageGroup.getCheckedRadioButtonId();
        String ticketType;
        if(checkedId == R.id.child_button){
            ticket.setAge(kid);
            ticketType = "Child";
        } else if(checkedId == R.id.adult_button){
            ticket.setAge(adult);
            ticketType = "Adult";
        } else {
            ticket.setAge(senior);
            ticketType = "Senior";
        }

        String taxStr = taxRate.getText().toString().replace("%","");
        if(taxStr.length() < 1){
            total.setText(R.string.error);
        } else {
            ticket.setTaxRate(Double.parseDouble(taxStr));
            base.setText(String.format(getString(R.string.subtotal_placeholder), ticketType, ticket.getBase()));
            tax.setText(String.format(getString(R.string.taxTotal_placeholder), ticket.getTaxRate()));
            total.setText(String.format(getString(R.string.total_placeholder),ticket.getPrice()));
        }
    }
}

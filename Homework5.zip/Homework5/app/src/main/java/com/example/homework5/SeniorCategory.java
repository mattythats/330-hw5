package com.example.homework5;

public class SeniorCategory implements AgeCategory {
    private double price = 12;
    @Override
    public double givePrice() {
        return price;
    }
}
